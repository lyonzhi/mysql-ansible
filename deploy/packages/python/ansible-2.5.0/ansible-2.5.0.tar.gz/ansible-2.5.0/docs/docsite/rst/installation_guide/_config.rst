.. This is a hack to allow doc references to files in other subdirectories.

.. include:: ../reference_appendices/config.rst
