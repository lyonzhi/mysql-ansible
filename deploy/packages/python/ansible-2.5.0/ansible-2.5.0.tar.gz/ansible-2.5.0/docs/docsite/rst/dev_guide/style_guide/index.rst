.. Ansible Style Guide documentation master file, created by
   sphinx-quickstart on Mon May 11 12:41:35 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

====================================
Ansible Style Guide
====================================

.. Welcome to Ansible Style Guide's documentation! ===============================================

.. toctree::
  :maxdepth: 1
  :numbered:

  self
  why_use
  resources
  basic_rules
  voice_style
  trademarks
  grammar_punctuation
  spelling_word_choice 
  

.. Indices and tables 
.. ================== 

.. * :ref:`genindex` 
.. * :ref:`modindex` 
.. * :ref:`search`
