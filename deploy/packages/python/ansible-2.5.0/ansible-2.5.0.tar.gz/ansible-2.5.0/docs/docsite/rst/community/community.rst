Community Information & Contributing
````````````````````````````````````

This page is deprecated. Please see the updated `Ansible Community Guide <http://docs.ansible.com/ansible/latest/community/index.html>`_.
