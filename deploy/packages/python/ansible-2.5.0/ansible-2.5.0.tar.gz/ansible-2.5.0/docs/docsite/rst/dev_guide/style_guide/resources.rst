Resources
````````````````
Internal resources
-------------------------
- https://docs.ansible.com/
- https://sites.google.com/a/ansibleworks.com/ansible-intranet/
- ??? intranet Engineering doc???


External Resources
-------------------------
- https://www.apstylebook.com
- http://www.chicagomanualofstyle.org/home.html
- https://www.crockford.com/wrrrld/style.html
- http://orwell.ru
- http://www.computeruser.com
