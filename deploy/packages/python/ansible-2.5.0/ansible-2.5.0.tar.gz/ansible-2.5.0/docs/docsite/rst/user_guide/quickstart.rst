Ansible Quickstart
==================

We've recorded a short video that introduces Ansible.

The `quickstart video <https://www.ansible.com/quick-start-video>`_ is about 13 minutes long and gives you a high level
introduction to Ansible -- what it does and how to use it. We'll also tell you about other products in the Ansible ecosystem. 

Enjoy, and be sure to visit the rest of the documentation to learn more.
